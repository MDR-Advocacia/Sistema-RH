--
-- PostgreSQL database dump
--

\restrict YeWAV1rfqI9KrbMr6hnS8vr54cfB3tWGMCmCs3yV0hJfkcF5Xpuv0keIdBSZkng

-- Dumped from database version 16.10 (Debian 16.10-1.pgdg13+1)
-- Dumped by pg_dump version 16.10 (Debian 16.10-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO admin;

--
-- Name: aviso; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.aviso (
    id integer NOT NULL,
    titulo character varying(200) NOT NULL,
    conteudo text NOT NULL,
    data_publicacao timestamp without time zone,
    autor_id integer NOT NULL,
    arquivado boolean NOT NULL
);


ALTER TABLE public.aviso OWNER TO admin;

--
-- Name: aviso_anexo; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.aviso_anexo (
    id integer NOT NULL,
    nome_arquivo_original character varying(255) NOT NULL,
    path_armazenamento character varying(512) NOT NULL,
    aviso_id integer NOT NULL
);


ALTER TABLE public.aviso_anexo OWNER TO admin;

--
-- Name: aviso_anexo_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.aviso_anexo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.aviso_anexo_id_seq OWNER TO admin;

--
-- Name: aviso_anexo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.aviso_anexo_id_seq OWNED BY public.aviso_anexo.id;


--
-- Name: aviso_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.aviso_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.aviso_id_seq OWNER TO admin;

--
-- Name: aviso_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.aviso_id_seq OWNED BY public.aviso.id;


--
-- Name: documento; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.documento (
    id integer NOT NULL,
    nome_arquivo character varying(255) NOT NULL,
    tipo_documento character varying(100) NOT NULL,
    path_armazenamento character varying(512) NOT NULL,
    funcionario_id integer NOT NULL,
    data_upload timestamp without time zone,
    requisicao_id integer,
    status character varying(50) NOT NULL,
    revisor_id integer,
    data_revisao timestamp without time zone,
    observacao_revisao text
);


ALTER TABLE public.documento OWNER TO admin;

--
-- Name: documento_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.documento_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.documento_id_seq OWNER TO admin;

--
-- Name: documento_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.documento_id_seq OWNED BY public.documento.id;


--
-- Name: feedback; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.feedback (
    id integer NOT NULL,
    feedback text NOT NULL,
    data timestamp without time zone,
    avaliador_id integer NOT NULL,
    avaliado_id integer NOT NULL
);


ALTER TABLE public.feedback OWNER TO admin;

--
-- Name: feedback_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.feedback_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.feedback_id_seq OWNER TO admin;

--
-- Name: feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.feedback_id_seq OWNED BY public.feedback.id;


--
-- Name: funcionario; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.funcionario (
    id integer NOT NULL,
    nome character varying(120) NOT NULL,
    status character varying(50) NOT NULL,
    cpf character varying(25) NOT NULL,
    email character varying(120) NOT NULL,
    telefone character varying(50),
    cargo character varying(100),
    setor character varying(100),
    data_nascimento date,
    contato_emergencia_nome character varying(120),
    contato_emergencia_telefone character varying(50),
    foto_perfil character varying(255),
    apelido character varying(50),
    data_desligamento date
);


ALTER TABLE public.funcionario OWNER TO admin;

--
-- Name: funcionario_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.funcionario_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.funcionario_id_seq OWNER TO admin;

--
-- Name: funcionario_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.funcionario_id_seq OWNED BY public.funcionario.id;


--
-- Name: funcionario_sistemas; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.funcionario_sistemas (
    funcionario_id integer NOT NULL,
    sistema_id integer NOT NULL,
    status character varying(50),
    observacao character varying(255)
);


ALTER TABLE public.funcionario_sistemas OWNER TO admin;

--
-- Name: log_ciencia_aviso; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.log_ciencia_aviso (
    id integer NOT NULL,
    aviso_id integer NOT NULL,
    usuario_id integer NOT NULL,
    data_ciencia timestamp without time zone
);


ALTER TABLE public.log_ciencia_aviso OWNER TO admin;

--
-- Name: log_ciencia_aviso_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.log_ciencia_aviso_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.log_ciencia_aviso_id_seq OWNER TO admin;

--
-- Name: log_ciencia_aviso_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.log_ciencia_aviso_id_seq OWNED BY public.log_ciencia_aviso.id;


--
-- Name: permissao; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.permissao (
    id integer NOT NULL,
    nome character varying(100) NOT NULL,
    descricao character varying(255)
);


ALTER TABLE public.permissao OWNER TO admin;

--
-- Name: permissao_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.permissao_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.permissao_id_seq OWNER TO admin;

--
-- Name: permissao_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.permissao_id_seq OWNED BY public.permissao.id;


--
-- Name: permissoes_usuarios; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.permissoes_usuarios (
    usuario_id integer NOT NULL,
    permissao_id integer NOT NULL
);


ALTER TABLE public.permissoes_usuarios OWNER TO admin;

--
-- Name: ponto; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.ponto (
    id integer NOT NULL,
    data_ajuste date NOT NULL,
    tipo_ajuste character varying(50) NOT NULL,
    justificativa text,
    path_assinado character varying(512),
    status character varying(50) NOT NULL,
    data_solicitacao timestamp without time zone,
    data_upload timestamp without time zone,
    observacao_rh text,
    funcionario_id integer NOT NULL,
    solicitante_id integer,
    revisor_id integer
);


ALTER TABLE public.ponto OWNER TO admin;

--
-- Name: ponto_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.ponto_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ponto_id_seq OWNER TO admin;

--
-- Name: ponto_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.ponto_id_seq OWNED BY public.ponto.id;


--
-- Name: requisicao_documento; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.requisicao_documento (
    id integer NOT NULL,
    tipo_documento character varying(100) NOT NULL,
    status character varying(50) NOT NULL,
    data_requisicao timestamp without time zone,
    data_conclusao timestamp without time zone,
    observacao text,
    solicitante_id integer NOT NULL,
    destinatario_id integer NOT NULL
);


ALTER TABLE public.requisicao_documento OWNER TO admin;

--
-- Name: requisicao_documento_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.requisicao_documento_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.requisicao_documento_id_seq OWNER TO admin;

--
-- Name: requisicao_documento_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.requisicao_documento_id_seq OWNED BY public.requisicao_documento.id;


--
-- Name: sistema; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.sistema (
    id integer NOT NULL,
    nome character varying(100) NOT NULL,
    categoria character varying(50)
);


ALTER TABLE public.sistema OWNER TO admin;

--
-- Name: sistema_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.sistema_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sistema_id_seq OWNER TO admin;

--
-- Name: sistema_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.sistema_id_seq OWNED BY public.sistema.id;


--
-- Name: usuario; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.usuario (
    id integer NOT NULL,
    email character varying(120) NOT NULL,
    password_hash character varying(256) NOT NULL,
    funcionario_id integer,
    senha_provisoria boolean NOT NULL,
    data_consentimento timestamp without time zone
);


ALTER TABLE public.usuario OWNER TO admin;

--
-- Name: usuario_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.usuario_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.usuario_id_seq OWNER TO admin;

--
-- Name: usuario_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.usuario_id_seq OWNED BY public.usuario.id;


--
-- Name: aviso id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.aviso ALTER COLUMN id SET DEFAULT nextval('public.aviso_id_seq'::regclass);


--
-- Name: aviso_anexo id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.aviso_anexo ALTER COLUMN id SET DEFAULT nextval('public.aviso_anexo_id_seq'::regclass);


--
-- Name: documento id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.documento ALTER COLUMN id SET DEFAULT nextval('public.documento_id_seq'::regclass);


--
-- Name: feedback id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.feedback ALTER COLUMN id SET DEFAULT nextval('public.feedback_id_seq'::regclass);


--
-- Name: funcionario id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.funcionario ALTER COLUMN id SET DEFAULT nextval('public.funcionario_id_seq'::regclass);


--
-- Name: log_ciencia_aviso id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.log_ciencia_aviso ALTER COLUMN id SET DEFAULT nextval('public.log_ciencia_aviso_id_seq'::regclass);


--
-- Name: permissao id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.permissao ALTER COLUMN id SET DEFAULT nextval('public.permissao_id_seq'::regclass);


--
-- Name: ponto id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ponto ALTER COLUMN id SET DEFAULT nextval('public.ponto_id_seq'::regclass);


--
-- Name: requisicao_documento id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.requisicao_documento ALTER COLUMN id SET DEFAULT nextval('public.requisicao_documento_id_seq'::regclass);


--
-- Name: sistema id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.sistema ALTER COLUMN id SET DEFAULT nextval('public.sistema_id_seq'::regclass);


--
-- Name: usuario id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.usuario ALTER COLUMN id SET DEFAULT nextval('public.usuario_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.alembic_version (version_num) FROM stdin;
bb5b1cc18a47
\.


--
-- Data for Name: aviso; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.aviso (id, titulo, conteudo, data_publicacao, autor_id, arquivado) FROM stdin;
1	Aviso – Gympass	Minha Recomendação\r\nSe tivéssemos que priorizar, a ordem de implementação seria:\r\n\r\nBackups Automatizados: É a tarefa mais crítica. Não se lança um produto sem rede de segurança para os dados.\r\n\r\nLogging Centralizado: É o que vai te permitir entender o que os usuários alpha estão fazendo e onde os problemas acontecem.\r\n\r\nTratamento de Erros: É uma melhoria relativamente rápida que tem um grande impacto na percepção de profissionalismo do sistema.\r\n\r\nRevisão de Permissões: Garantir que a segurança básica está sólida.\r\n\r\nMinha sugestão é começarmos pelos Backups. Posso te guiar na criação de um script de backup simples que pode ser integrado ao seu ambiente Docker. O que acha?	2025-08-21 13:26:52.974579	1	t
\.


--
-- Data for Name: aviso_anexo; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.aviso_anexo (id, nome_arquivo_original, path_armazenamento, aviso_id) FROM stdin;
1	68a7165f40177.pdf	6ef1c148-fe0b-4419-8b5f-cfee11b895b7.pdf	1
\.


--
-- Data for Name: documento; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.documento (id, nome_arquivo, tipo_documento, path_armazenamento, funcionario_id, data_upload, requisicao_id, status, revisor_id, data_revisao, observacao_revisao) FROM stdin;
\.


--
-- Data for Name: feedback; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.feedback (id, feedback, data, avaliador_id, avaliado_id) FROM stdin;
\.


--
-- Data for Name: funcionario; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.funcionario (id, nome, status, cpf, email, telefone, cargo, setor, data_nascimento, contato_emergencia_nome, contato_emergencia_telefone, foto_perfil, apelido, data_desligamento) FROM stdin;
1	Pedro Arthur Magalhães Alecrim	Ativo	700.205.494-58	pedro@mdradvocacia.com	(84) 99210-0671	Dev e Suporte	TI	2003-07-28	Marcia	(84) 998636655	654b5004-690b-458e-8ad8-a87c86ab0616.jpg		\N
2	Eliezer Nascimento De Souza	Ativo	75140853434	eliezer.souza@mdradvocacia.com	(84) 99407-1614	Nao Informado	BB - Autor Negocial	1973-03-25	Fatima (Esposa)	84991466637	\N	\N	\N
3	Rodrigo Cavalcanti	Ativo	00858007401	rodrigocavalcanti@mdradvocacia.com	84996256733	Nao Informado	Diretoria	1979-11-21	Renata Cavalcanti	Esposa	\N	\N	\N
4	Shirley Saionara Linhares De Oliveira	Ativo	01107072492	shirley.linhares@mdradvocacia.com	84 99999-2532	Nao Informado	BB - Encerramento	1981-08-08	Shirley	84 99999-2532	\N	\N	\N
5	Geovanna A. Bezerra Batista	Ativo	01229378480	geovanna.bezerra@mdradvocacia.com	84981294900	Nao Informado	Ativos - Reu	1982-11-16	Fischer	84999065792	\N	\N	\N
6	Jesebel Lorena Batista Oliveira Da Silva	Ativo	04603866461	jesebel.batista@mdradvocacia.com	(84) 99402-5530	Nao Informado	Controladoria	1984-12-15	Jose Batista (Pai)	84-99407-5527	\N	\N	\N
7	Landi Gleizy Ribeiro Da Silva	Ativo	05473146473	landi.silva@mdradvocacia.com	(83) 99193-6295 (mãe)	Nao Informado	RH	1984-12-16	Lani (Irma)	(83) 9.9196-9691	\N	\N	\N
8	Wilton De Medeiros Lima	Ativo	06758129411	wilton.lima@mdradvocacia.com	84999145248	Nao Informado	Ativos - Reu	1987-07-27	Judson (Du)	8499626-2651	\N	\N	\N
9	Christiane Serejo Cardoso	Ativo	05468630435	christianeserejo@mdradvocacia.com.br	84986112500	Nao Informado	BB - Reu	1988-05-27	Samu	192	\N	\N	\N
10	Hellen Sthefane Dos Santos Fernandes	Ativo	08758385452	hellennivea84@gmail.com	8499997-6224	Nao Informado	BB - Recursos	1988-06-22		84988528845	\N	\N	\N
11	Luana De Araujo Alves	Ativo	07598913463	luanaaraujo.alves@hotmail.com	84999296199	Nao Informado	BB - Autor Processual	1988-08-06	Sabrina Kelly	84996716889	\N	\N	\N
12	Arthur Augusto Alves De Almeida	Ativo	38777528883	aalves.arthur@gmail.com	(11)949399976	Nao Informado	BB - Reu	1989-11-09			\N	\N	\N
13	Mirta Maria Da Silva Sousa	Ativo	07637249476	apoiomdradv@gmail.com	84 996501005	Nao Informado	Mirta	1990-04-13		84 99828-6861	\N	\N	\N
14	Nayara De Souza Xavier	Ativo	08997488481	nayarasxavierr@gmail.com	84988568014	Nao Informado	BB - Autor Processual	1990-06-18	Samuel	8499981145	\N	\N	\N
15	Luana Silva Da Costa	Ativo	09455283450	luana@mdradvocacia.com	84998964598	Nao Informado	Ativos - Reu	1991-09-10	Wagner	84 99986-4378	\N	\N	\N
16	Rildon Pimentel Pereira	Ativo	01672980461	rildon@mdradvocacia.com	(84) 99802-4000	Nao Informado	TI	1993-08-15	Clenilda (Mae)	(84) 99607-0931	\N	\N	\N
17	Jonilson Vilela Cid Junior	Ativo	09841732424	jonilsonvilela@mdradvocacia.com	84981811597	Nao Informado	Diretoria	1993-08-27	Beatriz	84981588957	\N	\N	\N
18	Diego Alves Do Nascimento	Ativo	10454081405	diego.nascimento@mdradvocacia.com	84 999252170	Nao Informado	BB - Autor Processual	1994-04-05	Damiao Alves Do Nascimento	84998398628	\N	\N	\N
19	Marilia De Melo Oliveira	Ativo	10544598431	mari.melo15@hotmail.com	84988859342	Nao Informado	Controladoria	1994-05-20	Junior	84999383645	\N	\N	\N
20	Danielle Costa Alves	Ativo	10800380436	daniellecostaalves.adv@gmail.com	(84) 99906-4108	Nao Informado	BB - Reu	1994-07-12	Maria Da Piedade Costa Alves	(84) 992001450	\N	\N	\N
22	Gustavo Silva Abdias	Ativo	10850736455	gustavo.abdias@mdradvocacia.com	84 9857-8353	Nao Informado	BB - Autor Negocial	1994-09-28	Katia Cilene	84 9857-8353	\N	\N	\N
23	Luana Dos Santos Silva	Ativo	01732391459	luanasilva.proge@gmail.com	84996875823	Nao Informado	BB - Autor Processual	1994-11-29	Breno	84991996088	\N	\N	\N
25	Camilla Souza Silva	Ativo	01145434290	ssmcamilla@gmail.com	(84) 99827-3152	Nao Informado	Ativos - Reu	1995-05-17	Guilherme (Esposo)	(84) 9 9481-7732	\N	\N	\N
26	Priscila Cartonilho De Souza Ramos	Ativo	01143668294	cartonilhopriscila@gmail.com	(83) 9 9857-6034	Nao Informado	BB - Autor Processual	1995-07-03	Neto (Irmao)	(83) 9 9611-2246	\N	\N	\N
27	Andressa Baranoski Mello	Ativo	05717959940	andressa.baranoski@mdradvocacia.com	45 99914-1512	Nao Informado	BB - Recursos	1995-09-06	Pedro Mello	45 99999-1620	\N	\N	\N
28	Tathianna Ribeiro Da Silva Lemos	Ativo	10480432406	tathianna.adv@gmail.com	84996058095	Nao Informado	BB - Autor Processual	1995-09-20	Sabrina Ribeiro	84994341174	\N	\N	\N
29	Alvaro Andriellys De Brito Alves	Ativo	10382521480	alvaro.alves@mdradvocacia.com	84996312684	Nao Informado	BB - Recursos	1995-11-27	Alesandra De Brito Alves	84996360888	\N	\N	\N
30	Luna Raquel Acurcio Almeida	Ativo	10399891447	luna.almeida@mdradvocacia.com	84996252986	Nao Informado	RH	1996-02-08	Helverth Lins	84999585882	\N	\N	\N
31	Alyssa Georgia Bezerra E Silva	Ativo	11182041400	advgeorgiabezerra@gmail.com	84996994977	Nao Informado	BB - Recursos	1996-04-16	Ivanete Silva	84999153991	\N	\N	\N
32	Arlisson Pereira Da Silva	Ativo	01830804405	arlisson.silva@mdradvocacia.com	84996302766	Nao Informado	Ativos - Autor	1996-07-10	Adelson - Pai	84996583221	\N	\N	\N
33	Antonio Uemerson De Carvalho	Ativo	01732154406	antonio.carvalho@mdradvocacia.com	84 9166-8770	Nao Informado	BB - Recursos	1997-01-08	Ana Paula	84 9470-7080	\N	\N	\N
34	Ana Vitoria De Souza Silva	Ativo	09520601406	vitoriasouzahss@gmail.com	84991363489	Nao Informado	BB - Autor Processual	1997-01-18	Clesia Rener De Souza Silva	84994669879	\N	\N	\N
35	Ingrid Quirino Ribeiro	Ativo	09343294433	ingrid.quirino@mdradvocacia.com	83 993851616	Nao Informado	BB - Recursos	1997-02-18	Rafael	84 9126-9574	\N	\N	\N
36	Ana Carolina Viana Nascimento	Ativo	09613735470	ana.nascimento@mdradvocacia.com	84994278869	Nao Informado	BB - Recursos	1997-04-14	Diego Alves Do Nascimento	8499925-2170	\N	\N	\N
37	Algacy Chaves De Almeida Junior	Ativo	09872488479	algacyjunior@gmail.com	(84)998028896	Nao Informado	BB - Recursos	1997-10-14	Regina Cassia Dos Reis Almeida	84 99640-5223	\N	\N	\N
38	Leonardo Santos De Araujo	Ativo	08322838433	Leonardo.araujo@mdradvocacia.com	84999833172	Nao Informado	Ativos - Reu	1997-10-25	Cinthia	84999540123	\N	\N	\N
39	Francisco Diarkelangelo Nogueira De Souza	Ativo	01832418430	diarkelangelo@mdradvocacia.com	84994805514	Nao Informado	BB - Acordo Reu	1998-02-16	Eulina Angela	(84) 99818-4538	\N	\N	\N
40	Vitoria Machado Domingo	Ativo	09892560493	vitoria.domingo@mdradvocacia.com	84988933198	Nao Informado	BB - Autor Processual	1998-03-31	Fatima	84988932425	\N	\N	\N
41	Jose Leonardo De Araujo Jales	Ativo	04866012420	leonardojales.adv@gmail.com	(84) 98108-5374	Nao Informado	BB - Recursos	1998-05-28	Mayara	(84) 98748-1357	\N	\N	\N
43	Sthefanie De Melo Medeiros Queiroz	Ativo	11109978413	sthefanie.queiroz@mdradvocacia.com	84981391998	Nao Informado	Ativos - Autor	1998-08-10	Stenio Medeiros Queiroz	84999824913	\N	\N	\N
42	Jose Antonio De Souza Neto	Ativo	70527418498	neto@mdradvocacia.com	84996985082	Nao Informado	TI	1998-05-29	Adriane Franca Nogueira	85987445820	\N	\N	\N
44	Joao Vinicius Lucena Lopes	Ativo	12339292409	joao.lopes@mdradvocacia.com	84981770301	Nao Informado	BB - Autor Ajuizamento	1998-12-03	Maiara	55 84 9949-2044	\N	\N	\N
45	Victoria Karolliny Da Silva Pereira	Ativo	08465903441	victoriakarolliny532@gmail.com	84999196581	Nao Informado	BB - Recursos	1998-12-04	Marlene	84998353741	\N	\N	\N
46	Adson Nathan Santos Da Silva	Ativo	70107463466	adsonnathan2@gmail.com	84987451121	Nao Informado	BB - Cadastro	1998-12-10	Adjani Maria	84988663827	\N	\N	\N
47	Rafael Sampaio Bezerra	Ativo	12133303430	rafael.bezerra@mdradvocacia.com	84991269574	Nao Informado	BB - Autor Negocial	1999-02-07	Ingrid Quirino Ribeiro	83 993851616	\N	\N	\N
48	Joao Vitor De Araujo Pereira	Ativo	04665061475	adv.joaovitor22512@outlook.com	(84) 9.8702-9299	Nao Informado	BB - Reu	1999-04-04	Joao Vitor	84987029299	\N	\N	\N
49	Vinicius Victor De Sousa Silva	Ativo	07032596444	viniciusvictorvasil@outlook.com	84 996823578	Nao Informado	BB - Autor Processual	1999-04-12	Sueli Da Silva Costa	84987555958	\N	\N	\N
50	Afonso Rodrigues De Souza	Ativo	06339542417	afonso.souza@mdradvocacia.com	84996060709	Nao Informado	Ativos - Reu	1999-04-13	Cristina	84999215038	\N	\N	\N
51	Joao Lucas Dantas De Azevedo	Ativo	11630152455	joaolucas_dantass@hotmail.com	84981426978	Nao Informado	BB - Reu	1999-05-07		84981426978	\N	\N	\N
52	Gabriel Carvalho Rodrigues De Oliveira	Ativo	09421053460	gabriel.oliveira@mdradvocacia.com	8498840-3225	Nao Informado	BB - Recursos	1999-06-21	Francisco Joao De Oliveira Neto ( Meu Pai)	8499402-0143	\N	\N	\N
53	Maria Gabrielly Silva Rodrigues	Ativo	13133801481	mgabriellysr1999@gmail.com	84 99697-9340	Nao Informado	BB - Autor Processual	1999-09-18	Andre Azevedo	84 99192-7025	\N	\N	\N
54	Alexia Marinne Maia Fernandes	Ativo	12372203436	alexia.fernandes@mdradvocacia.com	84996006501	Nao Informado	BB - Autor Negocial	1999-10-02	Messias	84988011855	\N	\N	\N
55	Bruno Pinheiro De Lima Filho	Ativo	01767641435	bruno.pinheiro@mdradvocacia.com	(84) 99669-2049	Nao Informado	BB - Recursos	1999-11-04	Kesia	(84) 99129-6887	\N	\N	\N
56	Melissa Cristine De Oliveira E Santos	Ativo	08043121419	melissa.cristine10@gmail.com	84999283737	Nao Informado	BB - Autor Processual	1999-11-10	Mel	84 999283737	\N	\N	\N
57	Giovane Victor Nascimento Da Silva	Ativo	13207476473	giovane.silva@mdradvocacia.com	(84) 99663-1843	Nao Informado	Ativos - Reu	2000-03-03	Leandro Pai	(84) 9924-2034	\N	\N	\N
58	Enzo Pinto Bagatoli Carrico	Ativo	70426986490	enzopbc@gmail.com	(84) 99608-3254	Nao Informado	BB - Reu	2000-03-22	Ana Claudia Barbosa Pinto Carrico - Mae	(84) 99828-7477	\N	\N	\N
60	Ana Silvia Cruz Da Silva	Ativo	70739878476	ana.silva@mdradvocacia.com	84994836208	Nao Informado	BB - Acordo Reu	2000-08-29	Ana Paula	84994651899	\N	\N	\N
61	Jose Alberto Veloso De Carvalho	Ativo	12244537439	alberto.veloso@mdradvocacia.com	(84) 99208-5972	Nao Informado	Ativos - Reu	2000-10-17	Jussara Milena (Mae)	84996108070	\N	\N	\N
62	Denize De Medeiros Silva	Ativo	12431326470	denize.medeiros@mdradvocacia.com	84 991922986	Nao Informado	BB - Autor Processual	2000-11-14	Gilda	84 988845836	\N	\N	\N
63	Felipa Galvao Da Mota Liz Saraiva	Ativo	70036954489	felipa.saraiva@mdradvocacia.com	849116482	Nao Informado	Ativos - Autor	2000-12-21	- Victor Saraiva	84981817228	\N	\N	\N
64	Leticia Da Silva Mathias Baptista	Ativo	13493706650	leticia.baptista@mdradvocacia.com	(84) 99181-6633	Nao Informado	Ativos - Reu	2001-01-10	Luciana Da Silva Lucio Mathias	(84) 99166-4888	\N	\N	\N
65	Marcelli Gomes Do Nascimento	Ativo	18024049708	marcelligomes51@gmail.com	21980923994	Nao Informado	BB - Autor Ajuizamento	2001-01-23	Giovanny	84 9188-6690	\N	\N	\N
66	Maria Luisa De Brito Ferreira	Ativo	10979615402	MLUISAFERREIRADV@GMAIL.COM	849 8804-9889	Nao Informado	BB - Reu	2001-05-09	Beatriz (Irma)	84 98725-7775	\N	\N	\N
67	Axel De Araújo Brito	Ativo	01797431471	axel.brito@mdradvocacia.com	8499972-3865	Nao Informado	Ativos - Reu	2001-05-14	Cassia(Mae)	8498754-2946	\N	\N	\N
68	Adja Sanzia Queiroz De Araujo	Ativo	13766190407	sanziadja@gmail.com	84999874879	Nao Informado	BB - Acordo Reu	2001-06-07	Joana D’Arc	84 99988-8037	\N	\N	\N
69	Jennifer Camile Macedo Rodrigues	Ativo	70929869400	jenniferrodrigues@mdradvocacia.com	84 98104-8884	Nao Informado	BB - Reu	2001-06-22	Mara Macedo	84 9708-4104	\N	\N	\N
70	Nicholas Matheus Braga Da Fonseca	Ativo	12382573481	nicholas.braga.mdr@gmail.com	(84) 98736-3372	Nao Informado	BB - Encerramento	2001-07-31	Vanessa	(84) 98736-3372	\N	\N	\N
71	Brigida Brenda Faustino De Oliveira	Ativo	01772439452	brigida.oliveira@mdradvocacia.com	84986303268	Nao Informado	BB - Encerramento	2001-08-20	Rejane (Mae)	84988113033	\N	\N	\N
72	Alexandre Victor Da Silva Lima	Ativo	70118984411	alexandrevictor397@gmail.com	84988165939	Nao Informado	BB - Recursos	2001-11-14	Auricelho Gancalves De Lima	84988552667	\N	\N	\N
73	Cicera Larissa Da Silva Andrade	Ativo	12067805410	cicera.andrade@mdradvocacia.com	84988807199	Nao Informado	Ativos - Reu	2002-01-07	Maria	84 99646-4429	\N	\N	\N
74	Breno Medeiros De Andrade	Ativo	70393808467	medeirosb209@gmail.com	(84) 98822-6130	Nao Informado	BB - Reu	2002-01-08	Lucineide	84988543805	\N	\N	\N
75	Suenia Beatriz Lima De Carvalho Da Silva	Ativo	70776344420	sueniabeatriz.direito1@gmail.com	84987026239	Nao Informado	Ativos - Reu	2002-01-20	Heider (Pai)	84 98784-0466	\N	\N	\N
77	Yasmin Maria Albuquerque Da Costa Falcao	Ativo	13537584431	yasminfalcao12@icloud.com	84988855280	Nao Informado	BB - Reu	2002-02-15	Romana - Mae	(84) 996899559	\N	\N	\N
78	Lorena Silva De Moraes	Ativo	70069809410	lorena.moraes97@gmail.com	84 988053239	Nao Informado	BB - Encerramento	2002-02-15	Laura Cely Silva De Moraes	84 98865-4442	\N	\N	\N
79	Yan Moura Montenegro	Ativo	12093292475	yannatal2002@gmail.com	84 99709 1324	Nao Informado	RH	2002-04-02	Eunice	84 99635 9914	\N	\N	\N
80	Cinthia Samylle Martins Souza Da Silva	Ativo	70285046462	cinthiammdr@gmail.com	84999540123	Nao Informado	BB - Reu	2002-06-11	Weuder	84 99892-3333	\N	\N	\N
81	Pedro Viton Moura De Almeida	Ativo	70969236409	pedro.almeida@mdradvocacia.com	84996764357	Nao Informado	BB - Cadastro	2002-06-11	Gilvan	84997083820	\N	\N	\N
82	Allan Daniel Torres Soares	Ativo	11713733412	allan.soares@mdradvocacia.com	8499918-4225	Nao Informado	BB - Autor Processual	2002-06-15	Joana D'Arc Torres F.	84987188167	\N	\N	\N
83	Eduardo Henrique De Oliveira	Ativo	70068272480	eduardo.oliveira@mdradvocacia.com	84 986292962	Nao Informado	BB - Encerramento	2002-07-01	Lara Madruga	84 99192-7132	\N	\N	\N
84	Mateus Rodrigues De Brito	Ativo	09000010462	mateusrodb@outlook.com	84 99670-2503	Nao Informado	BB - Autor Processual	2002-08-19	Mariana	84 98765-8115	\N	\N	\N
85	Paulo Guilherme Morais De Almeida	Ativo	10674015479	pauloalmeidamdr@gmail.com	84 94222266	Nao Informado	BB - Autor Ajuizamento	2002-09-16	Iris	84 992093418	\N	\N	\N
86	Fernanda Rocha Romano	Ativo	13266844424	fernanda.romano@mdradvocacia.com	84988159761	Nao Informado	BB - Acordo Reu	2002-10-31	Elisangela Luzia De Oliveira Rocha	84988091999	\N	\N	\N
87	Luis Eduardo Costa Barbalho E Cunha	Ativo	07990752484	luiseduardo849@gmail.com	84996639867	Nao Informado	BB - Cadastro	2002-12-26		84996639867	\N	\N	\N
88	Debora Regina Azevedo De Oliveira	Ativo	10622654403	deborahregina135@gmail.com	(84)981392518	Nao Informado	BB - Recursos	2003-02-28	Francisca	(84)994114803	\N	\N	\N
89	Fernando Gabriel Noronha Nascimento	Ativo	70891642412	fernandogabrielnoronha@gmail.com	(84) 99428-7482	Nao Informado	BB - Reu	2003-03-31	Suzy Noronha	(84) 99605-6601	\N	\N	\N
90	Luiz Eduardo Oliveira Da Silva	Ativo	71286522480	luiz.silva@mdradvocacia.com	84994185088	Nao Informado	BB - Autor Negocial	2003-04-04	Luiz	84994185088	\N	\N	\N
91	Luise Yasmin De Franca Rodrigues	Ativo	70343363429	luise.rodrigues@mdradvocacia.com	84 99162-7358	Nao Informado	BB - Acordo Reu	2003-05-16	Kenia Katarina De Franca Rodrigues	84 99104-7387	\N	\N	\N
92	Raphael Gonzaga Bezerra Da Silva	Ativo	08479809442	raphael.silva@mdradvocacia.com	84 996133103	Nao Informado	Ativos - Reu	2003-07-30		84 981554186	\N	\N	\N
93	Carlos Eduardo De Almeida Beezerra	Ativo	70445481480	carlos.bezerra@mdradvocacia.com	84986278618	Nao Informado	BB - Recursos	2003-08-10	Marcia	84999250108	\N	\N	\N
94	Iuryanne Pereira De Medeiros	Ativo	13052958461	iuryanne.medeiros@mdradvocacia.com	84996836546	Nao Informado	Ativos - Reu	2003-08-13	Michely Pereira	84997068641	\N	\N	\N
95	Endrew Luan Gomes Ferreira	Ativo	06221138442	endrew.ferreira@mdradvocacia.com	84988718433	Nao Informado	Ativos - Reu	2003-08-22	Katia Cilene Dos Santos Gomes	84988727534	\N	\N	\N
96	Anne Caroline Ferreira Da Silva	Ativo	12610558457	anne.carol@hotmail.com.br	(84) 98778-2241	Nao Informado	BB - Cadastro	2003-09-22	Cissa Souza	(84) 98744-4143	\N	\N	\N
97	Eloiza Ellen Da Silva Santos	Ativo	70470743417	eloizaellen79@gmail.com	84 99423-3744	Nao Informado	BB - Cadastro	2003-09-26	Agostinho	84 999447300	\N	\N	\N
98	Marcus Vinicius Fernandes Gomes	Ativo	07043075459	marcusvfg64@gmail.com	(84) 99633-8771	Nao Informado	BB - Autor Processual	2003-10-22	Sharlene	(84) 99933-9959	\N	\N	\N
99	Luiz Eduardo Gondim Silva	Ativo	01685806406	eduardo.silva@mdradvocacia.com	(84) 98137-8503	Nao Informado	BB - Acordo Reu	2003-12-26	Samuel Silva	84 8161-7230	\N	\N	\N
100	Vitor Rafael De Freitas Fernandes	Ativo	15230884436	vitor.fernandes@mdradvocacia.com	84 98633-7894	Nao Informado	BB - Acordo Reu	2004-02-06	Iozilane	84 98623-3599	\N	\N	\N
101	Dennis Carvalho De Farias E Azevedo	Ativo	70100881440	carvalhodennis10@gmail.com	84991027473	Nao Informado	BB - Recursos	2004-03-17	Beatriz	84 99992-6433	\N	\N	\N
102	Mel Fernandes Da Conceicao Lebeis Pires Firmino	Ativo	11908282436	melfernandes778@gmail.com	84 99982-6532	Nao Informado	BB - Reu	2004-05-18	Gabriel Firmino	84 9 9918-9246	\N	\N	\N
103	Maria Luiza De Oliveira Araujo	Ativo	70990252442	marialuizadeoliveiraaraujo@gmail.com	(84) 98863-9677	Nao Informado	BB - Cadastro	2004-06-11	Juliana	(84) 988119441	\N	\N	\N
104	Gabriel Davi Gondim Sena Barbosa	Ativo	13422695435	gabrielcurriculo7@gmail.com	84991918675	Nao Informado	BB - Cadastro	2004-07-09	Zaira Carla Alves Gondim	84994156097	\N	\N	\N
105	Ana Julya Fernandes Freitas	Ativo	13242540417	ana.freitas@mdradvocacia.com	(84) 98627-0469	Nao Informado	Ativos - Reu	2004-08-18	Rosiene (Mae)	(84) 98878-1750	\N	\N	\N
106	Bernardo Dantas De Lima	Ativo	71069829463	bernardo.lima@mdradvocacia.com	84996757608	Nao Informado	Ativos - Autor	2004-09-01	Mercia	84987222950	\N	\N	\N
107	Caio Bezerril De Lima Galvao	Ativo	08821766411	caio.galvao@mdradvocacia.com	(84) 99692-3693	Nao Informado	Ativos - Reu	2004-09-12	Aurino Galvao (Pai)	(84) 98144-4466	\N	\N	\N
108	Leticia Fortunato De Sousa	Ativo	01694787427	study.leticia28@gmail.com	84 999062742	Nao Informado	BB - Autor Processual	2004-09-28	Debora	984 999582639	\N	\N	\N
109	Tayna Costa Souza	Ativo	10824096428	tayna.csouza1@gmail.com	(84) 99210-4750	Nao Informado	BB - Reu	2004-09-30	Romina Andressa Costa	(84) 99974-6551	\N	\N	\N
110	Celio Junior Caeira Dos Santos	Ativo	70646863410	celiocaeira@gmail.com	84 991014797	Nao Informado	BB - Cadastro	2004-10-29		84 991701725	\N	\N	\N
111	Ligia Reboucas Fagundes Lima	Ativo	70064609480	ligia.lima@mdradvocacia.com	84 99970-0188	Nao Informado	BB - Acordo Reu	2004-11-05	 - Nezia (Mae)	84 99995-6157	\N	\N	\N
112	Davi Santos Gomes Netto	Ativo	11955224447	davigomesnetto@gmail.com	(84) 98130-5332	Nao Informado	Ativos - Reu	2004-12-18	Marcelo	84 99407-7587	\N	\N	\N
113	Yasmin De Brito Saldanha Carvalho	Ativo	10524926492	yasmindebritosc@gmail.com	084 998355012	Nao Informado	BB - Encerramento	2005-01-21	Pedro Henrique	84999424240	\N	\N	\N
114	Maria Eduarda Medeiros Caldas	Ativo	11574222414	eduardamedeiroscaldas@gmail.com	(84) 99843-1405	Nao Informado	BB - Encerramento	2005-05-20	Eduardo Caldas	(84) 99634-1232	\N	\N	\N
115	Amanda Simoes Costa Da Silva	Ativo	71672469481	amanda.simoes2005@gmail.com	84 997052757 - telefone de Amanda	Nao Informado	BB - Reu	2005-06-28	Vanilce	84996318044	\N	\N	\N
116	Maria Flavia Cardoso Hortencio	Ativo	01702477401	cardosomariaflavia6@gmail.com	84 98155-4186	Nao Informado	BB - Encerramento	2005-06-30	Fabia	84 98634-1981	\N	\N	\N
117	Pedro Henrique Dantas Gonçalves	Ativo	70913777455	pedro.goncalves@mdradvocacia.com	84999424220	Nao Informado	Ativos - Reu	2005-07-11	Hamlet Gonçalves (Pai)	84998382222	\N	\N	\N
118	Yasmim Karoline Bezerra Moura	Ativo	12723104427	ymimk.2005@gmail.com	84999066140	Nao Informado	BB - Reu	2005-07-18	Katia Fabiana (Mae)	84 996261280	\N	\N	\N
119	Maria Eduarda Guedes Cavalcante	Ativo	70122152409	dudagc08@gmail.com	84 998940080	Nao Informado	BB - Autor Ajuizamento	2005-08-08	Katia - Mae	55 84 99864-4141	\N	\N	\N
120	Joaquim Valerio Silva De Lima	Ativo	08793645481	joaquimsilvamdr@gmail.com	(84) 988602101	Nao Informado	BB - Encerramento	2005-08-22	Nycolly	8498856-4391	\N	\N	\N
121	Luis Guilherme Revoredo Martins	Ativo	08064613493	luis.martins.mdr@gmail.com	84987570919	Nao Informado	BB - Cadastro	2005-09-04	Liliany	988244055	\N	\N	\N
122	Antonio Felipe Barbosa Araujo	Ativo	70294459456	Antoniofelipe0409@gmail.com	84996251819	Nao Informado	BB - Cadastro	2005-09-04	Maria Do Carmo	84998137782	\N	\N	\N
123	Karolliny Oliveira Cavalcanti	Ativo	09235913462	karolliny.cavalcanti@mdradvocacia.com	(84) 99814-2150	Nao Informado	Ativos - Reu	2005-09-19	Viviane Oliveira Dos Santos	(84) 99697-8217	\N	\N	\N
124	Rebeca Chianca	Ativo	71257587463	rebecachianca1234@gmail.com	84988111897	Nao Informado	BB - Cadastro	2005-09-26	Maria Aparecida	84986116111	\N	\N	\N
125	Glenda Ines Gomes De Oliveira	Ativo	10949354414	inesglenda07@gmail.com	(84) 986097369	Nao Informado	BB - Cadastro	2006-02-10	Janne Gleidy	(84) 988734593	\N	\N	\N
126	Paulo Fernando Cisneiros Da Costa Reis Neto	Ativo	11156071461	paulonetoreis04@gmail.com	(84) 98178-2767	Nao Informado	BB - Autor Processual	2006-04-04	Max Paul	(84) 98816-2767	\N	\N	\N
127	Evandro Lucas Saraiva Barbosa	Ativo	11749730480	evandro.barbosa@mdradvocacia.com	84986422254	Nao Informado	Ativos - Reu	2006-06-21	Leia	84988867688	\N	\N	\N
128	Jessica Rodrigues Da Silva	Ativo	70963194410	jessica.silva@mdradvocacia.com	(84) 99413-7050	Nao Informado	Ativos - Reu	2006-10-18	Elizabeth Chagas (Mae)	(84) 99134-0725	\N	\N	\N
129	Marilia Gabriela Andrade Freitas	Ativo	08978499490	gabrielandrademdr@gmail.com	84981338225	Nao Informado	BB - Autor Processual	2006-10-31	Marcos	84 99972-0855	\N	\N	\N
130	Marcos Vinicius Cruz Bezerra	Ativo	09253924489	marcos.vini.cruz@outlook.com	84 999416343	Advogado	BB Reu	1996-11-28	Aimee	84 999416368	\N	\N	\N
131	Ana Carolyne Barbosa De Araujo	Ativo	08054764316	araujoana660@gmail.com	84 999347874	Advogada	BB Recursos	2000-02-03	Bruno Araujo	84 992296161	\N	\N	\N
132	Bruna Ivyna Aguiar Araujo	Ativo	07288729354	brunaivyna@gmail.com	84 991182622	Estagiaria	BB - Recursos	1999-11-11	Flavio	84 988206584	\N	\N	\N
133	usuario	Ativo	111	teste@teste.com	111	aa	aa	2000-01-01	fulano	222	\N	\N	\N
134	Larissa Vaz	Ativo	705.913.816-13	larissava64@gmail.com	(84) 99108-5185	Estagiária	BB - Recursos	2005-02-27	Renata	(84) 99108-5154	\N	\N	\N
135	Julia Cauany Rodrigues Nunes	Ativo	093.905.254-70	juliacauanyrn12@gmail.com	(84) 99962-9984	Jovem Aprendiz	Financeiro	2007-12-18			\N	\N	\N
136	Andrielly Duarte De Farias	Ativo	713.567.094-94	andrielly.farias@mdradvocacia.com	84987080958	Advogada	BB - Autor Processual	2002-02-09	Erivan Duarte	84988573134	\N	\N	\N
138	Murilo Francisco da Silva	Ativo	AD_murilo.silva	murilo.silva@mdr.local	\N	A Definir	A Definir	\N	\N	\N	\N	\N	\N
141	fulano	Ativo	0101	fulano@mdr.local	0101	0101	0101	2000-01-01	0101	0101	\N	\N	\N
21	Pedro Henrique Oliveira Da Costa	Desligado	04462909127	pedro.costa@mdradvocacia.com	Anonimizado	Nao Informado	BB - Reu	\N	Anonimizado	Anonimizado	\N	\N	2025-08-21
143	Roberto Mendes Pivotto	Desligado	171 171 171	roberto.pivotto@mdr.local	Anonimizado	Aprendiz profissional	Hub de inovação	\N	Anonimizado	Anonimizado	\N	\N	2025-08-21
59	Yasmin De Menezes Dantas	Desligado	Anonimizado	Anonimizado	Anonimizado	Nao Informado	BB - Reu	\N	Anonimizado	Anonimizado	\N	\N	2025-08-21
\.


--
-- Data for Name: funcionario_sistemas; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.funcionario_sistemas (funcionario_id, sistema_id, status, observacao) FROM stdin;
\.


--
-- Data for Name: log_ciencia_aviso; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.log_ciencia_aviso (id, aviso_id, usuario_id, data_ciencia) FROM stdin;
1	1	1	2025-08-21 13:27:10.997968
\.


--
-- Data for Name: permissao; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.permissao (id, nome, descricao) FROM stdin;
1	admin_rh	Permissão de admin_rh
2	admin_ti	Permissão de admin_ti
3	colaborador	Permissão de colaborador
\.


--
-- Data for Name: permissoes_usuarios; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.permissoes_usuarios (usuario_id, permissao_id) FROM stdin;
1	2
1	1
2	3
3	3
4	3
5	3
6	3
7	3
8	3
9	3
10	3
11	3
12	3
13	3
14	3
15	3
16	3
17	3
18	3
19	3
20	3
22	3
23	3
25	3
26	3
27	3
28	3
29	3
30	3
31	3
32	3
33	3
34	3
35	3
36	3
37	3
38	3
39	3
40	3
41	3
42	3
43	3
44	3
45	3
46	3
47	3
48	3
49	3
50	3
51	3
52	3
53	3
54	3
55	3
56	3
57	3
58	3
60	3
61	3
62	3
63	3
64	3
65	3
66	3
67	3
68	3
69	3
70	3
71	3
72	3
73	3
74	3
75	3
77	3
78	3
79	3
80	3
81	3
82	3
83	3
84	3
85	3
86	3
87	3
88	3
89	3
90	3
91	3
92	3
93	3
94	3
95	3
96	3
97	3
98	3
99	3
100	3
101	3
102	3
103	3
104	3
105	3
106	3
107	3
108	3
109	3
110	3
111	3
112	3
113	3
114	3
115	3
116	3
117	3
118	3
119	3
120	3
121	3
122	3
123	3
124	3
125	3
126	3
127	3
128	3
129	3
130	3
131	3
132	3
133	3
134	3
\.


--
-- Data for Name: ponto; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.ponto (id, data_ajuste, tipo_ajuste, justificativa, path_assinado, status, data_solicitacao, data_upload, observacao_rh, funcionario_id, solicitante_id, revisor_id) FROM stdin;
1	2025-08-21	Entrada no escritório	cheguei atrasado.	\N	Pendente	2025-08-21 13:29:07.455689	2025-08-21 13:30:22.395184	faltou assinatura.	1	1	1
\.


--
-- Data for Name: requisicao_documento; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.requisicao_documento (id, tipo_documento, status, data_requisicao, data_conclusao, observacao, solicitante_id, destinatario_id) FROM stdin;
\.


--
-- Data for Name: sistema; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.sistema (id, nome, categoria) FROM stdin;
\.


--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.usuario (id, email, password_hash, funcionario_id, senha_provisoria, data_consentimento) FROM stdin;
2	eliezer.souza@mdradvocacia.com	scrypt:32768:8:1$oPYfA2WVKrUPA2DH$ed331454562fcf0442c2a804249b4a2b06750399584306b20bf793e1e8066d8a5aab37dba4ce9ba1b0e355bff23addbae6c057d86771501635769baefe84e75a	2	t	\N
3	rodrigocavalcanti@mdradvocacia.com	scrypt:32768:8:1$lsVlv0WoRdit8uny$9cce84de0db86f29cfd26eaaf7ed3788dcd78663d64f825f24e64a42be3b26d36cec84f3da86984eea96f9f43491d2d72dd5f0c8a7f90aed45caa7f75b966d0d	3	t	\N
4	shirley.linhares@mdradvocacia.com	scrypt:32768:8:1$b4wlRW2G5pKWKr8R$2174cdecc7f11d06b5f2670956d93b12773cd27d4c96d9829fd075fc4ad836775fcf30b722a96cb34af4ace988d1a61357c6efce30dcce613e536199c29bf914	4	t	\N
5	geovanna.bezerra@mdradvocacia.com	scrypt:32768:8:1$nQv5Dd2PGqUIrpCH$0be14f334a0aa6e6b3bbcb613f3e6c24acbe1ae79b3893df942dc8fe9fb7d0f1eb45f23948884c1d27fb5ab1890607ca08da488dcacff9d0586e3c3f8c32f882	5	t	\N
6	jesebel.batista@mdradvocacia.com	scrypt:32768:8:1$Xm68r74SnO3DY6JO$8a6eed98cc67604109d471804dda289beec15aeb2df910c27105866ab2005aa0414e57e1c7a103a800eabc1972b2427afe6f01caf4f066ea113782fdd7dccc6a	6	t	\N
7	landi.silva@mdradvocacia.com	scrypt:32768:8:1$GhZe8hhHvE3xuXMQ$da31fa883230b4979b19bb28198aebebb392abc03fa7f2035863537102aebda3c63cec4fdebcf90af91f761fe8083e79199768942217d81a6856f6533ecd4d4b	7	t	\N
8	wilton.lima@mdradvocacia.com	scrypt:32768:8:1$ykK9z556I5Q9cnQv$d257edab94cd3965bd4e447368989d7737d96afc564b4cdd661b1956407479270855e76a86d295db7ee2fd1de42b83e235b5761eb981b9fd32a9fb66fff14e3b	8	t	\N
9	christianeserejo@mdradvocacia.com.br	scrypt:32768:8:1$4xzzHxFnRc0W2m5O$87556dd79eb81a09b1a628e97deccc7a7e5c146b22590acdb987133ce6df300ea115de845dc1fea67db95496e71931a958c54b84a165240d87b9bdb2e7339990	9	t	\N
10	hellennivea84@gmail.com	scrypt:32768:8:1$noXMJWUxoylLTZ23$343bdeabe16868827649ebc0d4be052be5d74791c7b60db855e57a574eb5cd41921b43e08438ec57e4b614180e61607d55b410d814dd329bd87ddb797da37a7b	10	t	\N
11	luanaaraujo.alves@hotmail.com	scrypt:32768:8:1$In4oXWW5uJ1FUl3v$0dd6ad9baa75c1949bd97badeb768a1af73ca39fcd8be0bc58fcd9688d4e3c38a45a9a6a9f141cae7f22fb5e0f13bbc78668147c6f0065f2e3593c5dcd112982	11	t	\N
12	aalves.arthur@gmail.com	scrypt:32768:8:1$A9p20qTNSaIr2AwT$6bfa24e4c3bec2fd163a2ba1c2b88d104da72e26a07792930f20588d6b420d6074bedae09f6d9456e6b804ec79ac349a0b6209f035369f7ed5d0c4b0d07b4196	12	t	\N
13	apoiomdradv@gmail.com	scrypt:32768:8:1$rYiTi2v6nf0rd9Hz$863dbb76e1c2e6b4a5389d10a88fab8e675adc38a6dbc7393bcade290b270ea529802b3c78b131c11f2620d26aa4ae96a4663e3e6300a437c88597226bf28e51	13	t	\N
14	nayarasxavierr@gmail.com	scrypt:32768:8:1$6CqUmtBCqJaBoPhV$705dfe897711edb92592fa3c81c779f723b5a77c8fe144c1b90ac1e20969743c0be1641c2db6b0530de14c7636412bd5e1179aae31c296a1a9e348aaadf1e6bd	14	t	\N
15	luana@mdradvocacia.com	scrypt:32768:8:1$BatdWdjHCB5y35XT$89e2a6904bf306e3cd2944de49ab72950a362a77c43737060dea37ecceb91b572da61b75bed414a022693f4c5378888f711f942f85d96e200e1a6f5f8dc24346	15	t	\N
16	rildon@mdradvocacia.com	scrypt:32768:8:1$qCBL2q89vnhY01iP$00ae8725f471106ac1f0b7acc38536dfcba4cd9ec35a0d152506a12c2808baa1b8b90cd2e29ebfe6d65d32aa28b440b57045e085abf0fbcbb70e0f8031d80e4a	16	t	\N
17	jonilsonvilela@mdradvocacia.com	scrypt:32768:8:1$OwuJi4H1G6f89oq4$f24d40078d7ee2ba858c781ba83ca256ba5099809cb07101e99523aff5f53b8b8344c92d2d939bbced64f4ad14675c05be0761e847510bdf3569a70ca3bc7ebc	17	t	\N
18	diego.nascimento@mdradvocacia.com	scrypt:32768:8:1$Yqrh6qLVuPPzNukk$ea61ca97ccaec13026e8f0e5b1ac0f7dd1dc025143e0f47c53a43d54ca8e5f178eb6eb87c63c738f60ec0c90fc765a49563464fe28aed7f30a5a4d0ece72864a	18	t	\N
19	mari.melo15@hotmail.com	scrypt:32768:8:1$F4tR3DrPOWD3eAVq$848f8accc11047d9ebd1dc6a6860be49fc4dcac5a268dddb96df9afd622ff57fb38f4528a8eb1221d151a9714d577ed1df20e8d1898da134bd531bf7245a0a65	19	t	\N
20	daniellecostaalves.adv@gmail.com	scrypt:32768:8:1$qiPvuz7refcmKxY8$be9967b68fc4d4ab054443939257aa10989b6cec3529d3f7d4d1f20231950a14be17a67233fbba86d89d81f2ff1f23d74e72f221666560300c4cec66a83ac93b	20	t	\N
21	pedro.costa@mdradvocacia.com	scrypt:32768:8:1$1Ro2Ame2AJYumrFo$bc64fa7f894d51820c02a02ed03a309d51f193a39a35021188e4308a348cd1aac6aa1b70264916331212b38e8ebe0a318f6a4697e6e22591ebc4f4129fe31e96	21	t	\N
22	gustavo.abdias@mdradvocacia.com	scrypt:32768:8:1$lUBPg8KkAiqZe61t$77e896300ac8bcc962c750518f54ee5186a8e74d0966278b7984dee0881a857e8c32d0a0f7b1308e342c53eaa0efea89df55bfc52e23aca3021e54209e6fe77e	22	t	\N
23	luanasilva.proge@gmail.com	scrypt:32768:8:1$lp5V0AtRoWpOPsht$ea2ae9a841aba7a63813a4b66774a3a4a403351643f1b58ebb64bee49c924979f4a0d8791dec2c74706bf4af43fc8206f567e8f5706d7bff77e837515e1cf5d1	23	t	\N
25	ssmcamilla@gmail.com	scrypt:32768:8:1$uROJqFj8JOwnSU1V$976098b488c13a080b4abbda1bb795808cfbbc4ae58e80dcecc4853372bca57444d464374c4a1998edf6d8089c1a9ae1d6d2f88084d2b1ddb72a2b7961ac93c4	25	t	\N
26	cartonilhopriscila@gmail.com	scrypt:32768:8:1$vmtyekK6hi9svOeo$6a7c42a558928561eefa993aa171907fe78b318c601b1023e0d66810216f88760c024d1c86057b40ab5251e31837b8c0feed0a88a728955619cbbfbb5da331a7	26	t	\N
27	andressa.baranoski@mdradvocacia.com	scrypt:32768:8:1$6DfK0LhwNQfld7QP$9cee74b5aab9cb9795870365a730eca34219f2579f6a8c6d9e9a2294385e65aa23b8d73a620274c6beb194e476356cad0284c0af41526e9deba6174461f72fc3	27	t	\N
28	tathianna.adv@gmail.com	scrypt:32768:8:1$eLlh2Gs25KdfhoUJ$e46e2087fd062350ea6d83e61fe8583cbfc6d510a9acbc5f8e259792b876c8781c85f28501c7688d1fccf5fb1cb407c9e5ed4e4c45aad7d03aae2656df6fdb4b	28	t	\N
29	alvaro.alves@mdradvocacia.com	scrypt:32768:8:1$TOjwoFzzlXopd61S$edf343e669a6cbf3b343270a56510b3f80de0db2aeb3344439a3864c53e243172cfdeb8c1db8ee9994eab17167fa838b2ae088da214c2444455bbdad9b4f718f	29	t	\N
30	luna.almeida@mdradvocacia.com	scrypt:32768:8:1$iR2vboNqmzIppzHm$aa91750ef06bb95d899bf18cfa6b7530963641f0ea94ce92d2ee0c052da04f7984c9c74b935607f468a2cef2042e65fbe9dc4087e5be807d4415b69d396aaa49	30	t	\N
31	advgeorgiabezerra@gmail.com	scrypt:32768:8:1$Zw7NXQPk42d9seip$3c4c718fbb155c7c104cebe1e33a9970c7b5a46c72fc51cf5457eaee9c4489164a122559b74f4d6389c8f397ebcadd8383b46d1890875def500f8df8bb646a68	31	t	\N
32	arlisson.silva@mdradvocacia.com	scrypt:32768:8:1$euEYBoDv3d3pRcUx$a4c3faf8454c6ff51efcfedaa67c95825d9cd980d5b974ddd87f5f74681fccef42ba8072930bc588c4b49138ad6f98b28fdf9b4b0d8050524f381c7de366b9b0	32	t	\N
33	antonio.carvalho@mdradvocacia.com	scrypt:32768:8:1$1UvjNiOhRjx3kRhT$fb40da71e9c556faaeabbbed48c34fb070e79c639f454562784c6700338859581a3376e984af6c1c84a2f4d79e6ced5184772587d6b13f0f9c719a34f6b0d889	33	t	\N
34	vitoriasouzahss@gmail.com	scrypt:32768:8:1$wt1cxa1PRvR828Qx$3a75095fb643ac21bd905364b5523d334d6ae6b4ab8fe7ae67a70b5186f9f4a97305f13a07c8be845a09208081f702fa2dd776164b37981882a26f1e4c8f4d8b	34	t	\N
35	ingrid.quirino@mdradvocacia.com	scrypt:32768:8:1$s5EYRLdt296rWD6W$3191b51848e30eaf30ce56e98023299042ea2c7949eca2c34fae115235be8e002b82a2b4f165638cefebe4efb195bace7e9e6e98d27943e76ae8a078c65f3194	35	t	\N
36	ana.nascimento@mdradvocacia.com	scrypt:32768:8:1$eXB8Yc4rTLJjMrZ7$dabf7f0db897cf15efad0cb201be880c42241248bdf1a2d5b5e23a76ba368ef7b75aa23331ec3a9796e46ce8cb43b0d705844a5ff272a38c64b2f1b2ad3223ff	36	t	\N
37	algacyjunior@gmail.com	scrypt:32768:8:1$pBptpZDBxctYtFaI$076c4f3f58b9a85a7839bd5ae8fe2de0ecc734850f4325a6d43e8995ae696fdaf7aefa592edf7330720b9b1dee9d1324cd51f4aade53e01662177ef1e66546a4	37	t	\N
38	Leonardo.araujo@mdradvocacia.com	scrypt:32768:8:1$OIuuld0Pby3Cd3A4$ea59ac033d2524ddf71b9726738e565ca9d5100db3440f6d62618c99df3260dfebb0faeba4e01558231b5d0923052a4e2aa639df3b100101c0a538b0c46617a8	38	t	\N
39	diarkelangelo@mdradvocacia.com	scrypt:32768:8:1$eTQUmLt83QdbTgHM$551bcb2bf40ca57faf430b1f91efeeb665643da563ba7f2bcccecf368836738574f41489142bec2ca1e97f5a3bb0fb7702fa6da9c738093b6c24f6d63bc07779	39	t	\N
40	vitoria.domingo@mdradvocacia.com	scrypt:32768:8:1$x4ZMtiyaT9GrE38L$e9e4fafe42444db6cac5d05918edc406998d20d7e5efd7e62ab72f6ac8431ff78330c06daf9495b0b4ab84c17d4e3eddb43b49885e831d2a959be2397cb60870	40	t	\N
41	leonardojales.adv@gmail.com	scrypt:32768:8:1$n6qZE9inctUIfmOs$c5662718beeb468beb9f49a261f2e7aa2fe0ad832522e11249c8574be0c033d4c365a1319d873a69a01a18ec09d837bbf1c0237a5576bb7da27d96fd5d3f253e	41	t	\N
42	neto@mdradvocacia.com	scrypt:32768:8:1$QBFQ7yT4CZBcEmYv$8ec6bfa9f647de227d95286099e72b0669e0866cc668135f4bb0a7e8955372a4d1e3c5091c006f77443ae7dc19546c824341f51892880c0e8148a9827774b3c7	42	t	\N
43	sthefanie.queiroz@mdradvocacia.com	scrypt:32768:8:1$v6KMTqXjjfCKA9xi$78c667068b3da1a3d4eaf4e42ebc1f6d491c5cbea46740566e81f7e3da89ac6e823db19127983ec113e301d755c94836e44e24ac0c78df144b282523ff69e543	43	t	\N
44	joao.lopes@mdradvocacia.com	scrypt:32768:8:1$EWmNYLuCKMRKRXNi$c29fdeb042fb4daad794f774cf8fcaf985a6fa0d667427da5fd08ee5fb67bf3b6de96bd14f4a443f565e33e67b92fc07f63f1aca7fae721259994d9cc2c30d87	44	t	\N
45	victoriakarolliny532@gmail.com	scrypt:32768:8:1$AsLHG16q4IMLczEH$63d4054380ee4d0e6babf7fcd058219cab383eb4fb0445e18d58075742f860f68929458458e2d8652e36464a2798fcfe19cfd7cb7c30da708c3e478e3bd0040a	45	t	\N
46	adsonnathan2@gmail.com	scrypt:32768:8:1$YDHIN1xFmoX7gR3S$a51983740590d481e7f3905d35200c7ae8a3d7b36e180ed8ed4872ba0645693c13bc1c199ab6cc8bb34a356e682d45ca8e19fa2e279d3934776101dc73cfaa70	46	t	\N
47	rafael.bezerra@mdradvocacia.com	scrypt:32768:8:1$9kh95SVzIKlcwHbu$ca78a072680573a2d5f91b8112e3075802d45dd692c13c79c55d6923ece082852513a71f78f8873bc48ee158fb94dbf70efdb8044764f40b1a7d1c4e2408327a	47	t	\N
48	adv.joaovitor22512@outlook.com	scrypt:32768:8:1$S6HXkvMQqdyrucPK$c181dfc4e6b3edcb5d4d5dbc44ff1c136d1440a271c99ecbb7f55925510ae88418425f256bd056e55d676a2585f6425f1d4c5b1f5162707281a93b28581b3ac9	48	t	\N
49	viniciusvictorvasil@outlook.com	scrypt:32768:8:1$otMB1pljnwDo6AFq$ed5fe0c124897f9edc7870ef1ac42c387a7cf53aa544498136ae429e12a406b22b3edda7cca82c72a3f4328c1e830cab5d233ff93d832aa9293e1bff954c7e65	49	t	\N
50	afonso.souza@mdradvocacia.com	scrypt:32768:8:1$aVBF1OKCArwhDsOf$71e77bd52ec47619448af7dc2f4c20e6f9b8d49330bdfaac6c7ac879400be3fff1dc17cd97839fe32927cdc9b61cc1822a50e0d62965a752bb316b3fc8986ec9	50	t	\N
51	joaolucas_dantass@hotmail.com	scrypt:32768:8:1$PQEDQuAmgy0qB0Vj$a65d2a5d931e027b83154757eb0d28f6ef17112cfc363325c2b3e82241054ebaf05fbdbbc50e1341868d997fbcc7b6bbc525060a9b6d96b6d460ead8cbecc30a	51	t	\N
52	gabriel.oliveira@mdradvocacia.com	scrypt:32768:8:1$wmpBTy0hqBRMmUg4$62b9720f05e8e648923475f49c9b6c5961c21c36b8edd608be7033a735454573d7282ac911b3a97315cad25b098026679fbfc001f5b3bcbb42e838aea0da1278	52	t	\N
53	mgabriellysr1999@gmail.com	scrypt:32768:8:1$EsK9UEEkv64ktFvN$d8bb2e84163e26a9746257cfbaa499c14f0bef6a343ab553630b400214c6f4558c8da3180a21a81a7c43c25969cc44a8cfb3f1c31dcd5f7e47df08e73a2e04be	53	t	\N
54	alexia.fernandes@mdradvocacia.com	scrypt:32768:8:1$n2uJixVOogPEU1JK$c1befcfd21732bea72fd11b1c5e92020fb69dcbac24125869a4f14573814a1e416e24097b4b4b308a317b8c7af48461f957124d7aed6db0dab8f2cea704b5ae6	54	t	\N
55	bruno.pinheiro@mdradvocacia.com	scrypt:32768:8:1$ivq9KIwqIu7TjVdN$d32a813f33215cb1fbd8827b5ce9afcac71e06d143e0f5cd161b1ac5d0ad13fbfbfe9a6043e6b15107090ec05b5300e47bcf74ecc5e75148865abd1d226b0122	55	t	\N
56	melissa.cristine10@gmail.com	scrypt:32768:8:1$EXWh5JIhGlE09pU5$b33b4f597c9bde03c7e4d14a012732e81b0c899287878d78939331dc321e9b43f4bb3b65f868dfcb56afdc17755c902e7f8f66c0e9377abe1306d16472b74e88	56	t	\N
57	giovane.silva@mdradvocacia.com	scrypt:32768:8:1$fUW6f0vP61s7lf6k$a74e93004f7c141c93ec78a3ec5385ef094fd19d959e4cab38e298916a87e47aa4cc22ad6262be61d1bb3fb1f1c6a4ef5fb5d116c531ee05ff33ebdfe3d24667	57	t	\N
58	enzopbc@gmail.com	scrypt:32768:8:1$T2FsqiMelvoDCo1r$996355f9f7e0531de48800fda8b2e8e65bb26d7ddee1c56710d376851deb9efb83ed7d2928afc504af65ab851265bc0f5cfed6b5fcc291f0a42eaac2a1641c29	58	t	\N
59	yasmin.dantas@mdradvocacia.com	scrypt:32768:8:1$TffRF2csqqDDBxER$fcc517d06c3ca2af029a2a0260165af7edb2668216e3ea85546cc35ea7f3ca3958988157d19eea5c8d2c3ca3cd8281270edecdfcd34aa0821caa4c28472f41e4	59	t	\N
60	ana.silva@mdradvocacia.com	scrypt:32768:8:1$XXuE2dv69U29p7lt$160f08a083b8508099ebae99b5fa887a3cd49e169eedf5248163eb5549b5b0a6aea6b7ffda3b7daecd2ff14d4b077e7a7b381d294703e8092c8ad6dd8ffbd95a	60	t	\N
61	alberto.veloso@mdradvocacia.com	scrypt:32768:8:1$Tkq0fHVMqHeM8dnP$c8a5be7d432dba119fcb802a85c5a132b8edb8cacf13de71be97b61995cb0d654415b5751b1702044432bca6b8583a381540ec6bf71712aa4101e2f8cab20dcf	61	t	\N
62	denize.medeiros@mdradvocacia.com	scrypt:32768:8:1$49yTO1UxMTwVkH2I$60ac67b59771866fc5f7d08cf50b4b610d7641b958e3e8c98d5054d0e317dab22d65f072f0d02781a448bdd551ddfbdb10f5ed8bb8c8d46e795f5b6c13d6d01f	62	t	\N
63	felipa.saraiva@mdradvocacia.com	scrypt:32768:8:1$5eSMVG16ceug6V8G$349dea4a2c9774c17333d5a9d19b8ba641407f66333cda6e08693afde12c6cd8e789cb5d0443f80865cfdcac0813c9bc9c9fbf9b6f57d2dab8062320de2d78ed	63	t	\N
64	leticia.baptista@mdradvocacia.com	scrypt:32768:8:1$kFyhsXwdZVywKH2n$7f5003eefd39f769742c8236e22daad6f73c0ad38917d5fe5d469813f1a4b19bae07018a07e7b1e2e15d76f88c69bc704bac7717fc2835279f512d82b0e0cd93	64	t	\N
65	marcelligomes51@gmail.com	scrypt:32768:8:1$w4ZgADyaaEZShCEp$dd440cc00940cd8180caa1c25729d851be87c2452bcf235be7c6cd3fb25772d5fa68fb0485ef9a0fdea014495469a3cabba09e7d8f808b3ad84f1d87fe8451a7	65	t	\N
66	MLUISAFERREIRADV@GMAIL.COM	scrypt:32768:8:1$4oZ6zq2GA6uQZ1Ml$50e6bf02fd950c02b8034c013ab1f1317b6d949cbb3291fafc8b9d59d15818262ae598dfbed50345e91447df599d542c1c864099ee840f46ffb445633599d37f	66	t	\N
67	axel.brito@mdradvocacia.com	scrypt:32768:8:1$eUy6IiPssaa6ilRV$e18339a595b018459df648d8526ab7d428d39525b3181cf2034b32b62a4a1fc394c7a911fb4164608f726868853578e5fd80d8c77b206baee5756c5c24eb5558	67	t	\N
68	sanziadja@gmail.com	scrypt:32768:8:1$iMfAQJUX2PkalQxV$3bb0d37ee37da56e9d2c06153354a70f1cc95a53298d73eea2ee527878b8f8070b013c513d85a4e99d3b9614ce82d2d5ec6c2c83297fc88ec9d89417c43afb3a	68	t	\N
69	jenniferrodrigues@mdradvocacia.com	scrypt:32768:8:1$Y3jVCf6xNp6ivXR6$aa46bc8cb08ddeb38b79e4c0ac0fa859c4e3ae1fccbbe8d530288b0b982a792b1882349dbda6c1846e4d2a9e3adae684fa126015922d50e78e97bf0794dc1877	69	t	\N
70	nicholas.braga.mdr@gmail.com	scrypt:32768:8:1$RPRMpcCwxWVm6Xla$e30e0b5e3b5c226106a5f8ec8e2e963dcbef5d068f8e121008a8fa8026d08fe80ddc7d4886a89d9f3e9750caa8beb905385909f047388c6ad927f3b84403473f	70	t	\N
71	brigida.oliveira@mdradvocacia.com	scrypt:32768:8:1$J9E4hqYu9hdSjksd$8b58e82b8b4c67675133ddc331c729a9193297a810738db4b346eb871a4c814bbad2148fa62e7efde0ab9bc3ed20b3f17c244dc8a99bbbd152a80ff629c40c60	71	t	\N
72	alexandrevictor397@gmail.com	scrypt:32768:8:1$acOfrHGQB9hehtMm$ffad3b49d6777fe46e34b836b065d5ec01ca57df7edc384b3b1cddcf55a35a58515bdebfc731a41dcc327c0ac5c8200473a75662b9a055c3457f957fa41616bc	72	t	\N
73	cicera.andrade@mdradvocacia.com	scrypt:32768:8:1$q7Oe9cbdtxzSAKuv$8577cd00583847567d06c7d499569fd09be3678b59ba93bb9fafdcf49fddef80cfbfda15c0af1937a67bf5275e5409f8be2171b44fb9f9daf85e4956a7e688e0	73	t	\N
74	medeirosb209@gmail.com	scrypt:32768:8:1$XnYtFcJvzX5NCD0t$7776458601196287b8e364d6810cc3a9c9c0ead5c6d6f190f247320bbf8bee3d7c00a1cb7f421596ad32bb37db8b691877fa56763cf1c0603f1ae4d2408bfeb5	74	t	\N
75	sueniabeatriz.direito1@gmail.com	scrypt:32768:8:1$WSkX1fRr9wbWmlXz$d3a960291854cdeb6f76ac84d79ddf90549ac36b3a98aa3e6c988e1f6e720e7f8195b39ced4329afb6f4a1ecf51c5f4f2261847d45a2d1f2041a7313694e00de	75	t	\N
77	yasminfalcao12@icloud.com	scrypt:32768:8:1$G00YHt0zk5tn8TwI$1996d2911ca746723abf472d57126788b496ac523aaf9ad3ea45e6edde06a90a45fa2b6b71d013498a447f8e931d8fbe8e329f68901b024c95b3f148499e4d1d	77	t	\N
78	lorena.moraes97@gmail.com	scrypt:32768:8:1$X3OQjphm1nXXjkWK$99ca3c324dac0bfec2cf14c42e159c65d02c6cdc0a2033f417a9d340a5b346725a6eb2514ed9a74d6679ce121e3c914378e8989a5dd4ccca3b93aaef23c08837	78	t	\N
79	yannatal2002@gmail.com	scrypt:32768:8:1$jUnuxln7WmKQCDkN$fd33cf61f24db488a0d60d6c2a6c3eae917bf4913922b6a796e48f277011847542faf9fbf4edea278314607ce0ff6e942e9f2948a98b1f1079776edd65602217	79	t	\N
80	cinthiammdr@gmail.com	scrypt:32768:8:1$NcdlySfRNBDnDGry$9479fd7e4add3fa17b405aa70e98e4b08425b14a7c2538e9626e4d0f94faff3bcc7fce68d5a3a131552fe9cd3c42652bf1ccf309dac46466ad7e58a94a351319	80	t	\N
81	pedro.almeida@mdradvocacia.com	scrypt:32768:8:1$mX6zdg15VtF8RyPD$07770b5a3f05e887947f95e8d9a968a22e750511fda0dfd61c8847ecd8fb1e95f8c9d33cd2f82808cdc59bc1ab8e082cf7e85be604f2d344d1f87810936faa8b	81	t	\N
82	allan.soares@mdradvocacia.com	scrypt:32768:8:1$PPIfQ7n35J8rLEzN$e9da98811d88e6a16d20a92b56709dfb864e88576e8afb05a66d419491988389a6a1dea1546901066108eff5ccef02414799c7356c4bc70718d3a20bcc68e7b0	82	t	\N
83	eduardo.oliveira@mdradvocacia.com	scrypt:32768:8:1$1Rx2TchNSzNAoZcv$9453e6f95ef8ba511486215c48d1405f7a110ee2a0c8b31f48321458e9d8b38e80c52b1c05f45f34cf65808e78e9db8d0f539baa06a5025082cf6d7a3ee03619	83	t	\N
84	mateusrodb@outlook.com	scrypt:32768:8:1$IDUB7PFHC9UNMekJ$1b82e307bcea13a9b293a976e40cf89c93237fc9440cb7a201117b7c86d0d7fd5cde82a831261b8fecfaedd6f6b4f3408178ed21c685c312aa5f79d98fbc2f64	84	t	\N
85	pauloalmeidamdr@gmail.com	scrypt:32768:8:1$pWZJXGzgl4PZrknQ$fcbb022fe8b4754d0b0148db11cfe8341b1c7e3d0b524084e2cf34c615cdee9330e65ff815daffa2480f6fcd1d7e68609f71d992be84432413201e76863630f4	85	t	\N
86	fernanda.romano@mdradvocacia.com	scrypt:32768:8:1$dYMUZEhNHxzZRbh5$dcbb017d67b23bf3c795354ac1746444a7bfc8ff724219105595de270d3829943c24dcce0d12034910f05978958c4f4d23f9140d1832b84945d2d9e3685b0c3a	86	t	\N
87	luiseduardo849@gmail.com	scrypt:32768:8:1$LvebmpC48csH7WGg$674bf0d03da3e7a5efd50fa997155dea241b0e07a9f3fce8a271d88ea51bd631f9fdfd5ccf00d8d2ced8038401b8fb37610d5c43b1c47eadfb4a0caca973adcf	87	t	\N
88	deborahregina135@gmail.com	scrypt:32768:8:1$DgWt7bKwHTI3p8v4$79474e62bd896fcffefc31ae1f11ca9fead56a072667247cca847f2db09d20561647dc58809a47ee9decf3c43eeafd5e5122a35546a037131a3355af1e11136c	88	t	\N
89	fernandogabrielnoronha@gmail.com	scrypt:32768:8:1$xnqbwva1bvbcHtTg$4c260dce4f6e70d08b46ce72a53dfceadf2f1f845d42b0c5e614d54f15ea3f49d9c8180c6036f5c2b69210d0818df996ef5ed21991bdb0682a3953389d377616	89	t	\N
90	luiz.silva@mdradvocacia.com	scrypt:32768:8:1$jN5Lq0PY5yTiogCS$a93f4c752ac595c464f89b4bf119381d2a2695c4ca65f77bc8039c2cb3b8292b999266d3c7658940f1bff6546cadbfe71ada4f1aaa86cc579630854e8cc04cab	90	t	\N
91	luise.rodrigues@mdradvocacia.com	scrypt:32768:8:1$AlWtur7xPcRquqpr$4aafdc32b0fe0f376dfe932a2e417061b19a695bc8a87209f09462df9201f8fc2dc5c7ec3123ed25b21f465df07ab626b4ea2c096c0bff13249a7055d5948384	91	t	\N
92	raphael.silva@mdradvocacia.com	scrypt:32768:8:1$kYA1j3DNjktDgSpq$e32b6cc92e4b5ad3ab755b052e785ffdc9e464f23eeaa18d78244fe0c7435c0d6c3ccf2c0e16bb2eead7ba03f9404ce74d29bfdb2dd8feeff00a9af334618f73	92	t	\N
93	carlos.bezerra@mdradvocacia.com	scrypt:32768:8:1$CkJvYHRFVn3Wiuyj$738529007e052f2ea160145668c16af5d144c8d05b7b0a50ef7542d65eb5cc440bb04514767626282c52d72860dac554cfd12398947ced50e55df12e0ff33dfd	93	t	\N
94	iuryanne.medeiros@mdradvocacia.com	scrypt:32768:8:1$D2EOhBLrFBminGrN$6cacd8233aa7a476ae1cebd9d71150991b43ede8d8c4795c80734190d822ce27f37fc9ede882bdfe27e54e7d1d18adbdcc90e7ffe3838e284cb569f05823a17d	94	t	\N
95	endrew.ferreira@mdradvocacia.com	scrypt:32768:8:1$wmeJxp3Ss15wUHYQ$d34749d6fcb023e06ed017baf182265f06241e1f8af58cd3768f26d28413631d6134cef47d8cba1f59e0bbfdecc1064725ad6e74f26d4bed0603766c05973148	95	t	\N
96	anne.carol@hotmail.com.br	scrypt:32768:8:1$PAndF2GHPK5ewVmD$b28ca1c853d6645c96af0ea6f6a2f6b2a92490916934c4cb9bb5e72270d9f7686db744a55fe886271cd5ae2893eb86e9aac80d1c1e7d33afd43e9ed7d474ad4e	96	t	\N
97	eloizaellen79@gmail.com	scrypt:32768:8:1$NOiFhqQUOzZ7FkBM$e241de5b722070d36055e3eb68d627db8484cca9f888cbb22e4c9211d8d1b683d3231ae3cea0b4a588c920d2626dd8da9f5741c0675dcdd3b30528ccf3dc7ea6	97	t	\N
98	marcusvfg64@gmail.com	scrypt:32768:8:1$kXGnwXwXeff8wx8e$1876ee758f1d13427b743d38e987c0d592b05addb03abc3684930aee47f35a63c6fbfd0eda4e35673f35cf5b49c73429da5eb68f85a04cd877a87a24ede12e9f	98	t	\N
99	eduardo.silva@mdradvocacia.com	scrypt:32768:8:1$1ff1m7SSQ2AxS69L$3fab778a7d3a08e78763e97ea1d8dd2e860a9a371da8f3324578f1711bc817a9994ca434e1abe2d3dd7d2db20fa5eeefcd5075f614a47d36e114a66d2df6dcb3	99	t	\N
100	vitor.fernandes@mdradvocacia.com	scrypt:32768:8:1$TVb1HoppjjwWEMxz$ec12a9fd710e08179b2eef21d21c0e024e7250b53704699a8c0c03df7c86f4dc282ac582f6521caea00ccbffd4eeec69a82021010e11c7dcce2fbb02c5d01508	100	t	\N
101	carvalhodennis10@gmail.com	scrypt:32768:8:1$ImPpAUXX2VxltVg7$8b1230303676e09c4145d8409a5ac696ad05e9881cb76545148b8935ccbbee8e0846dfbf3e2ee0b7bc624d76484fab5e4037839b3886f43efe742de2581d3f09	101	t	\N
102	melfernandes778@gmail.com	scrypt:32768:8:1$XrbCaZ4SYXHgIOo4$f7bfb1f42cb715d605f930454b608c66761db2d025629f1b8a4f14ab85a1a54222c501d75d4febb455cdee48f2f40a0fb1b48d2b6ca2de21fd9453463d66b0d5	102	t	\N
103	marialuizadeoliveiraaraujo@gmail.com	scrypt:32768:8:1$ye7DHQ9nInMnRWa1$54c4ba41f3667e1ad14950974dc35f7a1abae5c7a1a6b3fea8b9eace5c63b3c0ee6d5c3ac5b8a4ee7104a7f0b5879787a796774f7dcf7e990d0e049f597e1451	103	t	\N
104	gabrielcurriculo7@gmail.com	scrypt:32768:8:1$tIbjeYfW2yypf2rU$1df85ad2c5150a6ce58064439d2495c764d72031d723e18ee0d8d4b1ad37e8dbcc3a3942097461ff912d6fb88cbcbdca1ed9ee6e185a088babf7b9acef215b64	104	t	\N
105	ana.freitas@mdradvocacia.com	scrypt:32768:8:1$Ql4hQEn6ejfsrxxC$1873a316c6d70c5b6e87731930ead305153e195cdbd884c84e32aded579dd8c169ca4042319ab3741466c3032f38f76311e97cccd1b5db19f6f25d36f2d18d68	105	t	\N
106	bernardo.lima@mdradvocacia.com	scrypt:32768:8:1$J5BUHFetvNQ9nlWz$0f8eae74a459d095aec3b13c3b7a979ff6878fcbe29b67c59eda68dd9d39ebb1ce5eefe582bf614a560ca677b20b7569c2dcd5e25392579197cc5ec2bdbf47f2	106	t	\N
107	caio.galvao@mdradvocacia.com	scrypt:32768:8:1$Smwkv64V996bbMPj$dc26a66ff87a79bffaa615773e53db5473d1c6fb8bf3e15b2e6bd57f7325cc71e3c00e24724865717555a874c92e9eb4e92e12f1e3c5e0a30a1e092fbf6a52cb	107	t	\N
108	study.leticia28@gmail.com	scrypt:32768:8:1$Znfbo408rHBQGmYU$50e4063d095d6294a730b11256a39a1e72f49d789c0c99c1b7f82bc552f0ee4c002d837ff8da0708c638c6aaab407581bcab5bc0756538f05b569d52bfb12f38	108	t	\N
109	tayna.csouza1@gmail.com	scrypt:32768:8:1$mG6ESFE0McjBeEK2$e9e4977ee1a22b3aacdae6e8483d1f6871026164d9a4d062980311252b84f74e02370d4e8e9cf616e2108fa22fcbcaa766952288116b0e85a7e3df1569314db7	109	t	\N
110	celiocaeira@gmail.com	scrypt:32768:8:1$eqlImARoGAUJpXZ7$b90eb11cf580eb5e9075e68fda566f9d413cc3c6b29525821b6f55ad0ac08101fe21a565d42566794e31f55707e643ca778b4ad675693a8cb31280c852ef2025	110	t	\N
111	ligia.lima@mdradvocacia.com	scrypt:32768:8:1$ES6JZnmpqqnRKtd5$8c49cc255e4d3d162171c07354582cec7e0e3574d99367272323a93766c09d96c56d14b9f54ca64871a9076f89c0b131594b1ffc18897343dbb61400b07ec588	111	t	\N
112	davigomesnetto@gmail.com	scrypt:32768:8:1$4cmlhaz5GjbCaNXU$0a05fee57cba55a75ef5fc4a5a794d26a8ccc8c84d5b7c5418cf67854017521ece3b547b35d5d17cb5cc655dc8130b918c86f4520152fa8aa9ca826b1ce0caed	112	t	\N
113	yasmindebritosc@gmail.com	scrypt:32768:8:1$km8Nsd9aFpWjOwa9$3e52ef1b939d900cacccbe391efd56f08b83dce2041be6ef4fb3a1ad5db7c67797b0dca18c5130ddf0dbb425a1888d3c91b0020b760267683afb69f645f1c5cb	113	t	\N
114	eduardamedeiroscaldas@gmail.com	scrypt:32768:8:1$HmyFty1M01tWrxKM$69010d8bebf685f2ef3228b5ec7b09b4db56b2acd9b77d9cb42eb93c44697fd6cb89770b3bec32edc73357be019cb4ea016d21f37830f50e3bbd683e60c78979	114	t	\N
115	amanda.simoes2005@gmail.com	scrypt:32768:8:1$QHpjB2jB674abfzL$db4f3f4a1350e280ee9a4f48cddeb7e4dd7b4554be1ce4ff3d692655baa7e0790b3742bf6006f4dd800333f436a70886bd65b13054be0afd0d24f629af64c7b6	115	t	\N
116	cardosomariaflavia6@gmail.com	scrypt:32768:8:1$CxI0ju86bwZze8Nr$8504174f92462c9ea445494ba16ff32016e85d940a222a6b35fc672b81cb477e27934dea64c1ea30e49fc7c7f71b608f1289789d381e93ee9ea854359b41b876	116	t	\N
117	pedro.goncalves@mdradvocacia.com	scrypt:32768:8:1$jH3EeOwY4xtDlyYz$dea116bf4c82e59862a0bc990d33c57a76d8d4992383db6933454e40c3ee7458a0e8aac510bedf5c7fa2683399083f9e465e0ddbc302793a1f903bbed5105adb	117	t	\N
118	ymimk.2005@gmail.com	scrypt:32768:8:1$L5BJGIXTtPiGdHgk$3aed8096c3568cf2ce85eff3c8ae9672cfd95a8f4630499a7a31d63664455fe0acee7b63e6951f696335bbd0b7def8fc89000a24b0a555cebbbe4cde5ab8ad92	118	t	\N
119	dudagc08@gmail.com	scrypt:32768:8:1$zlBSBsHiJqaRTbai$ee34aa76139d9e5fed3c294a958263be7e15d9fd6e8465ca2f3989ca8f5a7c94e42aac84dd54997f23fb151f106fed21c137baf5fe1d9823c82d1205f561a34d	119	t	\N
120	joaquimsilvamdr@gmail.com	scrypt:32768:8:1$gjAGVaLaqI0sc5EL$ad104a3ebf9d0937ec80884c1f45d3678f85ecbecfb4dfaffac99e55114c69f80d4d871b57d7c993d3bc8aae62a96a26c713e5716acd053f5fca6c9784e7ff3f	120	t	\N
121	luis.martins.mdr@gmail.com	scrypt:32768:8:1$2QGNWeVvfagp03yd$2624de70c6b6536a54590361d41501f366e94d9df4f789bd909be869811927ae6ba5fc996173f36196edf2b9c39e298ee84ebcce85ec2b09e8fb08982e31d85b	121	t	\N
122	Antoniofelipe0409@gmail.com	scrypt:32768:8:1$PURROwgVLPnTvpg4$3ab5836e1818155d786484fa4413a2bd9446baae4e51466945d57483707f19285287523b78a03563cbf51e202344c72c39a439074d6b736fe675ef5f61ce0795	122	t	\N
123	karolliny.cavalcanti@mdradvocacia.com	scrypt:32768:8:1$GZ0YykE0LwaQxc8m$4540219d8ef63d8cf0bdc1e383b864f667fe17e0bf8c53631c9ff197855963175fc022d94b5ef865d0aa625e3c0d0dbcc3ed04aa11942f10e380dfcb97068eb9	123	t	\N
124	rebecachianca1234@gmail.com	scrypt:32768:8:1$6pOhSGTE1FAiDBoV$e5d90a97ec69f08e33492af87a99b0c6a8cffffa87d0fc7471156e65301ad0b56b703acf57b749e8d7d2ef61464f3dd294c32ab657cf2cbed5a0a73c39e49ac7	124	t	\N
125	inesglenda07@gmail.com	scrypt:32768:8:1$vaDsjfTgYge8hH5E$8a3876903a4e2932222ef52510bcede0c1f7922ee06ba4bbb58f6b4e348f5e12e132151170cc9c64262c6ac591c3de0ec08a7c41bb7d9d9c6af115857717aa6d	125	t	\N
126	paulonetoreis04@gmail.com	scrypt:32768:8:1$ZX1ENhgUAuZRotjX$31f53284e4495f2f24ee0ce33b2e80183ad9d360540367391a7543543d6a8498133e0c64250e14ae0b3848a6f460d33a1196c9dcec3e58af8e0df79406a75f80	126	t	\N
127	evandro.barbosa@mdradvocacia.com	scrypt:32768:8:1$LsXS5ciFs9SB4L7K$a2fe9be20270d19b6b78395f8aef39b80f42951db97c2e7f382d9552fafa0648bdba5f2b398837a2ab8d2416cf7268878b32ea2651a6f31b110ed2a1726f8c46	127	t	\N
128	jessica.silva@mdradvocacia.com	scrypt:32768:8:1$GAxuyGgWI2BI7r21$2557dbf1dc18cbd628ebe2baf76fc794770b04abcb1e3acc237b2ebec6866a48cb1f3f6d32a0a4bece336b0068506a6bf6febe0e12baa564aee2687789027727	128	t	\N
129	gabrielandrademdr@gmail.com	scrypt:32768:8:1$V0D6aY7TbvgJ39Ge$f4d09c7650746f8f121e2d90a6111c4ef8568d7bfa0fb254525c2a6c4104f4224ca2df4211a7624ae0a9da18f55a6c047ed7c566d24848127df8494350c6525c	129	t	\N
130	marcos.vini.cruz@outlook.com	scrypt:32768:8:1$gOvQ93SKUrgs6542$397ab1f4019993d31ba6f844dfdbf819aa5c3c3ee5e36adb75833e60005475285a03be5187f9a53e82b769d49306e8d09299c49b883ef8ba6cdadb02a7bceed5	130	t	\N
131	araujoana660@gmail.com	scrypt:32768:8:1$Ymjbo5ULe1Q7IMRC$9c3e489a5700ea41ae584bb33d341d453dda83e7c13db2d46fdf0f2f193057415d346fe75d3b65c424007aeeaad0ab63fd5c35a1f7a27553fdfe36c8f0fcdafa	131	t	\N
132	brunaivyna@gmail.com	scrypt:32768:8:1$ubsdIglCGl4OTOtB$257c7129b53cf44f7a92d9f4d9a06015a49f56a97620a52336f83330f3641ccd5e635a0a3d925a3bee9ebb80a0051afdebd78b61b74f26e1cd6b40d90110baa5	132	t	\N
133	teste@teste.com	scrypt:32768:8:1$atoGmh25JJw2tO4F$854e5bded796489e40c19c81ecce48d47fc48a43ebf23145ca4c2c4ad32b46e4be8a74239d27d3b6a3d4ed5d2b29ed1213203dba553bff4a74db0e47a6c1b416	133	f	\N
134	andrielly.farias@mdradvocacia.com	scrypt:32768:8:1$wlQZpsM43sXY6Axr$471c9836d87e934ddeabdb39a6bb8150cff16e7b969e040c208379641524d599a60ae0dcefdf55bb569cc60ad7e395c2ad53c1e3149fa6f058d7ef6fd2359441	136	t	\N
136	murilo.silva@mdr.local	scrypt:32768:8:1$w2ga4vvwCAtY6B6a$931248ede10f6aea25cddfa8fddae8d22ab8d1cd602c07c7bb49f38b519bc0250178f8c9e037755da4c302a09e9451118b78fa12e6b400b175317bb728154f35	138	f	2025-08-21 13:35:08.200335
139	fulano@mdr.local	scrypt:32768:8:1$Pbqh932SVmzdsc5G$cef5d2d49e92b0568e69e9434a2fce48a012f225599704aa408c7c0cf28fcc57f6af27471f21ddca6ae294fb5686b66dd88b6065752631149f53ba6779735c43	141	f	\N
141	roberto.pivotto@mdr.local	scrypt:32768:8:1$AgHUdQgGTZxAI3QT$f03cc1b4d6fec6daf745e3ab557e104fbd079bc180e91937d2694e87e8fdabbf7a1228e3c569342dde531daf227707054fecdf7a50135ad4305862abf10a9551	143	f	\N
1	pedro.alecrim@mdr.local	scrypt:32768:8:1$MTZ5yKEoslzZqmkr$03d79c477cb417e3f61e75f45369d150bc62a5addd2a33a88de209ae7dc1ae9402f2a4fa7ca55573c85c3b59f6775485f053243efc410de5e1a56e7a9bb274c5	1	f	2025-08-20 20:59:36.092827
\.


--
-- Name: aviso_anexo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.aviso_anexo_id_seq', 1, true);


--
-- Name: aviso_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.aviso_id_seq', 1, true);


--
-- Name: documento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.documento_id_seq', 1, false);


--
-- Name: feedback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.feedback_id_seq', 1, false);


--
-- Name: funcionario_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.funcionario_id_seq', 144, true);


--
-- Name: log_ciencia_aviso_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.log_ciencia_aviso_id_seq', 1, true);


--
-- Name: permissao_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.permissao_id_seq', 1, false);


--
-- Name: ponto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.ponto_id_seq', 1, true);


--
-- Name: requisicao_documento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.requisicao_documento_id_seq', 1, false);


--
-- Name: sistema_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.sistema_id_seq', 1, false);


--
-- Name: usuario_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.usuario_id_seq', 142, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: aviso_anexo aviso_anexo_path_armazenamento_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.aviso_anexo
    ADD CONSTRAINT aviso_anexo_path_armazenamento_key UNIQUE (path_armazenamento);


--
-- Name: aviso_anexo aviso_anexo_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.aviso_anexo
    ADD CONSTRAINT aviso_anexo_pkey PRIMARY KEY (id);


--
-- Name: aviso aviso_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.aviso
    ADD CONSTRAINT aviso_pkey PRIMARY KEY (id);


--
-- Name: documento documento_path_armazenamento_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.documento
    ADD CONSTRAINT documento_path_armazenamento_key UNIQUE (path_armazenamento);


--
-- Name: documento documento_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.documento
    ADD CONSTRAINT documento_pkey PRIMARY KEY (id);


--
-- Name: feedback feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_pkey PRIMARY KEY (id);


--
-- Name: funcionario funcionario_cpf_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.funcionario
    ADD CONSTRAINT funcionario_cpf_key UNIQUE (cpf);


--
-- Name: funcionario funcionario_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.funcionario
    ADD CONSTRAINT funcionario_pkey PRIMARY KEY (id);


--
-- Name: funcionario_sistemas funcionario_sistemas_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.funcionario_sistemas
    ADD CONSTRAINT funcionario_sistemas_pkey PRIMARY KEY (funcionario_id, sistema_id);


--
-- Name: log_ciencia_aviso log_ciencia_aviso_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.log_ciencia_aviso
    ADD CONSTRAINT log_ciencia_aviso_pkey PRIMARY KEY (id);


--
-- Name: permissao permissao_nome_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.permissao
    ADD CONSTRAINT permissao_nome_key UNIQUE (nome);


--
-- Name: permissao permissao_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.permissao
    ADD CONSTRAINT permissao_pkey PRIMARY KEY (id);


--
-- Name: permissoes_usuarios permissoes_usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.permissoes_usuarios
    ADD CONSTRAINT permissoes_usuarios_pkey PRIMARY KEY (usuario_id, permissao_id);


--
-- Name: ponto ponto_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ponto
    ADD CONSTRAINT ponto_pkey PRIMARY KEY (id);


--
-- Name: requisicao_documento requisicao_documento_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.requisicao_documento
    ADD CONSTRAINT requisicao_documento_pkey PRIMARY KEY (id);


--
-- Name: sistema sistema_nome_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.sistema
    ADD CONSTRAINT sistema_nome_key UNIQUE (nome);


--
-- Name: sistema sistema_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.sistema
    ADD CONSTRAINT sistema_pkey PRIMARY KEY (id);


--
-- Name: usuario usuario_email_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_email_key UNIQUE (email);


--
-- Name: usuario usuario_funcionario_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_funcionario_id_key UNIQUE (funcionario_id);


--
-- Name: usuario usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (id);


--
-- Name: aviso_anexo aviso_anexo_aviso_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.aviso_anexo
    ADD CONSTRAINT aviso_anexo_aviso_id_fkey FOREIGN KEY (aviso_id) REFERENCES public.aviso(id);


--
-- Name: aviso aviso_autor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.aviso
    ADD CONSTRAINT aviso_autor_id_fkey FOREIGN KEY (autor_id) REFERENCES public.usuario(id);


--
-- Name: documento documento_funcionario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.documento
    ADD CONSTRAINT documento_funcionario_id_fkey FOREIGN KEY (funcionario_id) REFERENCES public.funcionario(id);


--
-- Name: documento documento_requisicao_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.documento
    ADD CONSTRAINT documento_requisicao_id_fkey FOREIGN KEY (requisicao_id) REFERENCES public.requisicao_documento(id);


--
-- Name: documento documento_revisor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.documento
    ADD CONSTRAINT documento_revisor_id_fkey FOREIGN KEY (revisor_id) REFERENCES public.usuario(id);


--
-- Name: feedback feedback_avaliado_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_avaliado_id_fkey FOREIGN KEY (avaliado_id) REFERENCES public.funcionario(id);


--
-- Name: feedback feedback_avaliador_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_avaliador_id_fkey FOREIGN KEY (avaliador_id) REFERENCES public.usuario(id);


--
-- Name: funcionario_sistemas funcionario_sistemas_funcionario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.funcionario_sistemas
    ADD CONSTRAINT funcionario_sistemas_funcionario_id_fkey FOREIGN KEY (funcionario_id) REFERENCES public.funcionario(id);


--
-- Name: funcionario_sistemas funcionario_sistemas_sistema_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.funcionario_sistemas
    ADD CONSTRAINT funcionario_sistemas_sistema_id_fkey FOREIGN KEY (sistema_id) REFERENCES public.sistema(id);


--
-- Name: log_ciencia_aviso log_ciencia_aviso_aviso_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.log_ciencia_aviso
    ADD CONSTRAINT log_ciencia_aviso_aviso_id_fkey FOREIGN KEY (aviso_id) REFERENCES public.aviso(id);


--
-- Name: log_ciencia_aviso log_ciencia_aviso_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.log_ciencia_aviso
    ADD CONSTRAINT log_ciencia_aviso_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuario(id);


--
-- Name: permissoes_usuarios permissoes_usuarios_permissao_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.permissoes_usuarios
    ADD CONSTRAINT permissoes_usuarios_permissao_id_fkey FOREIGN KEY (permissao_id) REFERENCES public.permissao(id);


--
-- Name: permissoes_usuarios permissoes_usuarios_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.permissoes_usuarios
    ADD CONSTRAINT permissoes_usuarios_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuario(id);


--
-- Name: ponto ponto_funcionario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ponto
    ADD CONSTRAINT ponto_funcionario_id_fkey FOREIGN KEY (funcionario_id) REFERENCES public.funcionario(id);


--
-- Name: ponto ponto_revisor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ponto
    ADD CONSTRAINT ponto_revisor_id_fkey FOREIGN KEY (revisor_id) REFERENCES public.usuario(id);


--
-- Name: ponto ponto_solicitante_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ponto
    ADD CONSTRAINT ponto_solicitante_id_fkey FOREIGN KEY (solicitante_id) REFERENCES public.usuario(id);


--
-- Name: requisicao_documento requisicao_documento_destinatario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.requisicao_documento
    ADD CONSTRAINT requisicao_documento_destinatario_id_fkey FOREIGN KEY (destinatario_id) REFERENCES public.funcionario(id);


--
-- Name: requisicao_documento requisicao_documento_solicitante_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.requisicao_documento
    ADD CONSTRAINT requisicao_documento_solicitante_id_fkey FOREIGN KEY (solicitante_id) REFERENCES public.usuario(id);


--
-- Name: usuario usuario_funcionario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_funcionario_id_fkey FOREIGN KEY (funcionario_id) REFERENCES public.funcionario(id);


--
-- PostgreSQL database dump complete
--

\unrestrict YeWAV1rfqI9KrbMr6hnS8vr54cfB3tWGMCmCs3yV0hJfkcF5Xpuv0keIdBSZkng

